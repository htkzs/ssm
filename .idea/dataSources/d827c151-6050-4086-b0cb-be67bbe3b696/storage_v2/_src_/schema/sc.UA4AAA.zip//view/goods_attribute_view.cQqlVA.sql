create definer = root@localhost view goods_attribute_view as
select `sc`.`goods`.`goods_id`                AS `goods_id`,
       `sc`.`goods`.`goods_name`              AS `goods_name`,
       `sc`.`goods`.`sales_price`             AS `sales_price`,
       `sc`.`goods`.`goods_img`               AS `goods_img`,
       `sc`.`attribute_name`.`attr_name_id`   AS `attr_name_id`,
       `sc`.`attribute_name`.`attr_name`      AS `attr_name`,
       `sc`.`attribute_value`.`attr_value_id` AS `attr_value_id`,
       `sc`.`attribute_value`.`attr_value`    AS `attr_value`
from `sc`.`goods`
         join `sc`.`attribute_name`
         join `sc`.`attribute_value`
         join `sc`.`goods_attribute`
where ((`sc`.`goods`.`goods_id` = `sc`.`goods_attribute`.`goods_id`) and
       (`sc`.`attribute_name`.`attr_name_id` = `sc`.`goods_attribute`.`attr_name_id`) and
       (`sc`.`attribute_value`.`attr_value_id` = `sc`.`goods_attribute`.`attr_value_id`));

