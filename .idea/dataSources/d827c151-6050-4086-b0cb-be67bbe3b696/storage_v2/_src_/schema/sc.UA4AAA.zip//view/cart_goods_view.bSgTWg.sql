create definer = root@localhost view cart_goods_view as
select `sc`.`cart`.`cart_id`                  AS `cart_id`,
       `sc`.`cart`.`user_id`                  AS `user_id`,
       `sc`.`cart`.`total_price`              AS `total_price`,
       `sc`.`cart`.`total_num`                AS `total_num`,
       `sc`.`cart_info`.`sku_id`              AS `sku_id`,
       `sc`.`goods_sku`.`sku_name`            AS `sku_name`,
       `sc`.`goods_sku`.`goods_id`            AS `goods_id`,
       `goods_attribute_view`.`goods_name`    AS `goods_name`,
       `goods_attribute_view`.`goods_img`     AS `goods_img`,
       `sc`.`goods_sku`.`price`               AS `price`,
       `sc`.`cart_info`.`buy_num`             AS `buy_num`,
       `goods_attribute_view`.`attr_name`     AS `attr_name`,
       `goods_attribute_view`.`attr_value`    AS `attr_value`,
       `goods_attribute_view`.`attr_name_id`  AS `attr_name_id`,
       `goods_attribute_view`.`attr_value_id` AS `attr_value_id`
from `sc`.`goods_attribute_view`
         join `sc`.`goods_sku`
         join `sc`.`cart_info`
         join `sc`.`cart`
where ((`goods_attribute_view`.`goods_id` = `sc`.`goods_sku`.`goods_id`) and
       (`sc`.`goods_sku`.`sku_id` = `sc`.`cart_info`.`sku_id`) and (`sc`.`cart_info`.`cart_id` = `sc`.`cart`.`cart_id`))
order by `sc`.`cart`.`cart_id`, `sc`.`cart_info`.`sku_id`;

