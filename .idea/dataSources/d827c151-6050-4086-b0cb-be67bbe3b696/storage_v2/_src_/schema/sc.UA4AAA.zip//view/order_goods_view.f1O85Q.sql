create definer = root@localhost view order_goods_view as
select `sc`.`orders`.`order_id`               AS `order_id`,
       `sc`.`orders`.`user_id`                AS `user_id`,
       `sc`.`orders`.`order_amount`           AS `order_amount`,
       `sc`.`orders`.`order_discount`         AS `order_discount`,
       `sc`.`orders`.`add_time`               AS `add_time`,
       `sc`.`orders`.`os_id`                  AS `os_id`,
       `sc`.`order_state`.`state_desc`        AS `state_desc`,
       `sc`.`order_detail`.`details_id`       AS `details_id`,
       `sc`.`order_detail`.`sku_id`           AS `sku_id`,
       `sc`.`goods_sku`.`sku_name`            AS `sku_name`,
       `sc`.`goods_sku`.`goods_id`            AS `goods_id`,
       `goods_attribute_view`.`goods_name`    AS `goods_name`,
       `goods_attribute_view`.`goods_img`     AS `goods_img`,
       `sc`.`order_detail`.`buy_price`        AS `buy_price`,
       `sc`.`order_detail`.`num`              AS `num`,
       `goods_attribute_view`.`attr_name`     AS `attr_name`,
       `goods_attribute_view`.`attr_value`    AS `attr_value`,
       `goods_attribute_view`.`attr_name_id`  AS `attr_name_id`,
       `goods_attribute_view`.`attr_value_id` AS `attr_value_id`
from `sc`.`goods_attribute_view`
         join `sc`.`goods_sku`
         join `sc`.`order_detail`
         join `sc`.`orders`
         join `sc`.`order_state`
where ((`goods_attribute_view`.`goods_id` = `sc`.`goods_sku`.`goods_id`) and
       (`sc`.`goods_sku`.`sku_id` = `sc`.`order_detail`.`sku_id`) and
       (`sc`.`order_detail`.`order_id` = `sc`.`orders`.`order_id`) and
       (`sc`.`orders`.`os_id` = `sc`.`order_state`.`os_id`))
order by `sc`.`orders`.`order_id`, `sc`.`order_detail`.`sku_id`;

